export default function Admin(){
 return <main className="admin"><div className="logo">Limeira <span>na Balada</span></div><h1 style={{fontSize:42}}>Painel Administrativo</h1>
 <p>Primeira base profissional. A próxima etapa é conectar este formulário ao Supabase Auth, banco de dados e Storage.</p>
 <div className="card"><h2>Novo evento</h2><input placeholder="Nome do evento"/><input type="date"/><input placeholder="Local"/><textarea placeholder="Descrição do evento"/><button className="btn">Salvar evento</button></div>
 <div className="card" style={{marginTop:18}}><h2>Enviar foto com marca d'água</h2><p>O backend já possui uma rota inicial preparada para processar a imagem automaticamente.</p></div>
 </main>;
}