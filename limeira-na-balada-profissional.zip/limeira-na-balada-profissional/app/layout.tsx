import "./globals.css";
export const metadata = { title: "Limeira na Balada", description: "Eventos, fotos e notícias de Limeira do Oeste - MG" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}