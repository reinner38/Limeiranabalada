const cards=[["🎉","Eventos","Shows, festas e agenda da cidade."],["📸","Fotos","Galerias com marca d'água do portal."],["📰","Notícias","Informações e novidades de Limeira do Oeste."]];
export default function Home(){
 return <><header className="wrap nav"><div className="logo">Limeira <span>na Balada</span></div><nav className="links"><a href="#eventos">Eventos</a><a href="#fotos">Fotos</a><a href="#noticias">Notícias</a><a href="/admin">Admin</a></nav></header>
 <main><section className="hero"><div className="wrap"><span className="badge">📍 LIMEIRA DO OESTE - MG</span><h1>Limeira <b>na Balada</b></h1><p>Eventos, festas, fotos e notícias de Limeira do Oeste e região.</p></div></section>
 <section className="section"><div className="wrap"><h2>Portal em construção 🚀</h2><div className="grid">{cards.map(([i,t,d])=><article className="card" key={t}><div className="cover">{i}<br/>LIMEIRA NA BALADA</div><h3>{t}</h3><p>{d}</p></article>)}</div></div></section></main></>;
}