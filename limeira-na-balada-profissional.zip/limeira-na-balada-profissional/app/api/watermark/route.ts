import { NextRequest, NextResponse } from "next/server";
import sharp from "sharp";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const file = form.get("image");
  if (!(file instanceof File)) {
    return NextResponse.json({error:"Envie uma imagem no campo image."},{status:400});
  }
  const input = Buffer.from(await file.arrayBuffer());
  const image = sharp(input);
  const meta = await image.metadata();
  const width = meta.width || 1200;
  const height = meta.height || 800;

  const svg = `<svg width="${width}" height="${height}">
    <style>
      .title{fill:white;font-size:${Math.max(24,Math.round(width/22))}px;font-family:Arial;font-weight:bold}
      .sub{fill:#ffd400;font-size:${Math.max(14,Math.round(width/40))}px;font-family:Arial;font-weight:bold}
    </style>
    <text x="50%" y="${height-55}" text-anchor="middle" class="title">LIMEIRA NA BALADA</text>
    <text x="50%" y="${height-22}" text-anchor="middle" class="sub">Limeira do Oeste - MG</text>
  </svg>`;

  const output = await image.composite([{input:Buffer.from(svg),top:0,left:0}]).jpeg({quality:90}).toBuffer();
  return new NextResponse(output,{headers:{"Content-Type":"image/jpeg","Content-Disposition":'attachment; filename="limeira-na-balada.jpg"'}});
}