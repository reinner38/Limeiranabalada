-- Limeira na Balada - estrutura inicial
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'editor' check (role in ('admin','editor')),
  created_at timestamptz default now()
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  event_date date,
  event_time time,
  location text,
  cover_url text,
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz default now()
);

create table if not exists news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique,
  content text not null,
  image_url text,
  status text not null default 'draft' check (status in ('draft','published')),
  published_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists galleries (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  event_id uuid references events(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists photos (
  id uuid primary key default gen_random_uuid(),
  gallery_id uuid references galleries(id) on delete cascade,
  original_url text not null,
  watermarked_url text not null,
  created_at timestamptz default now()
);

alter table events enable row level security;
alter table news enable row level security;
alter table galleries enable row level security;
alter table photos enable row level security;

create policy "public reads published events" on events for select using (status='published');
create policy "public reads published news" on news for select using (status='published');
create policy "public reads galleries" on galleries for select using (true);
create policy "public reads photos" on photos for select using (true);
